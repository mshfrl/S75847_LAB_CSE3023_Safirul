<%-- 
    Document   : login
    Created on : 12 May 2026, 3:32:02 pm
    Author     : Asus
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Log in</title>
    </head>
    <body>
        <h2>Login</h2>

        <%
            String msg = request.getParameter("msg");
            if (msg != null) {
                out.println("<p style='color:red; font-weight:bold;'>" + msg + "</p>");
            }
        %>

        <form action="doLogin.jsp" method="POST">
            <table border="0">
                <tr>
                    <td>Username:</td>
                    <td><input type="text" name="username" required></td>
                </tr>
                <tr>
                    <td>Password:</td>
                    <td><input type="password" name="password" required></td>
                </tr>
                <tr>
                    <td colspan="2"><input type="submit" value="Login"></td>
                </tr>
            </table>
        </form>
        <br>
        <a href="insertUser.html">Register a new account</a>
    </body>
</html>
