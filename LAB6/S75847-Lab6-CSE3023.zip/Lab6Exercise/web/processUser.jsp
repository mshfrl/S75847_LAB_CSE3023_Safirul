<%-- 
    Document   : processUser
    Created on : 12 May 2026, 3:28:15 pm
    Author     : Asus
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page language="java"%>
<%@page import="java.sql.*"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>process User</title>
    </head>
    <body>
        <h2>Registration Status</h2>
        <%
            String user = request.getParameter("username");
            String pass = request.getParameter("password");
            String fname = request.getParameter("firstname");
            String lname = request.getParameter("lastname");

            Connection conn = null;
            PreparedStatement pstmt = null;

            try {
                Class.forName("com.mysql.jdbc.Driver");
                String dbURL = "jdbc:mysql://localhost:3307/CSE3023";

               
                conn = DriverManager.getConnection(dbURL, "root", "");

                String sql = "insert into userprofile (username, password, firstname, lastname) values (?, ?, ?, ?)";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, user);
                pstmt.setString(2, pass);
                pstmt.setString(3, fname);
                pstmt.setString(4, lname);

                int result = pstmt.executeUpdate();

                if (result > 0) {
                    out.println("<p style='color:green;'>Registration successful for user: " + user + "</p>");
                    out.println("<a href='login.jsp'>Click here to login</a>");
                }

            } catch (Exception e) {
                out.println("<p style='color:red;'>Error during registration: " + e.getMessage() + "</p>");
            } finally {
                try {
                    if (pstmt != null) {
                        pstmt.close();
                    }
                } catch (SQLException e) {
                }
                try {
                    if (conn != null) {
                        conn.close();
                    }
                } catch (SQLException e) {
                }
            }
        %>
    </body>
</html>
