<%-- 
    Document   : main
    Created on : 12 May 2026, 3:42:37 pm
    Author     : Asus
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <%
            String username = (String) session.getAttribute("loggedUser");
            String firstname = (String) session.getAttribute("firstName");
            String lastname = (String) session.getAttribute("lastName");

           
            if (username == null) {
                response.sendRedirect("login.jsp?msg=Please login first.");
                return;
            }
        %>

        <div>
            <h2>Welcome to the System!</h2>
            <p><strong>Username:</strong> <%= username%></p>
            <p><strong>First Name:</strong> <%= firstname%></p>
            <p><strong>Last Name:</strong> <%= lastname%></p>
        </div>

        <br>
        <a href="login.jsp">Log Out</a>
    </body>
</html>
