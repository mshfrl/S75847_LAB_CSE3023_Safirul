<%-- 
    Document   : doLogin
    Created on : 12 May 2026, 3:35:15 pm
    Author     : Asus
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page language="java"%>
<%@page import="java.sql.*"%>
<%@page import="java.net.URLEncoder"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Do Login</title>
    </head>
    <body>
         <p><% request.getParameter("username"); %></p>
        <%
            String user = request.getParameter("username");
            String pass = request.getParameter("password");
            
            Connection conn = null;
            PreparedStatement pstmt = null;
            ResultSet rs = null;

            try {
                Class.forName("com.mysql.jdbc.Driver");
                String dbURL = "jdbc:mysql://localhost:3307/CSE3023";

                // Again, verify your root password here ("admin" or "")
                conn = DriverManager.getConnection(dbURL, "root", "");

                String sql = "SELECT * FROM userprofile WHERE username COLLATE utf8mb4_bin =? AND password COLLATE utf8mb4_bin=?";
                pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, user);
                pstmt.setString(2, pass);

                rs = pstmt.executeQuery();

                if (rs.next()) {
                    // Validation successful! 
                    // Extract firstname and lastname from the database result
                    String firstname = rs.getString("firstname");
                    String lastname = rs.getString("lastname");

                    // Save details to the server session so main.jsp can access them
                    session.setAttribute("loggedUser", user);
                    session.setAttribute("firstName", firstname);
                    session.setAttribute("lastName", lastname);

                    // Redirect to main.jsp
                    response.sendRedirect("main.jsp");
                } else {
                    // Validation unsuccessful! Redirect back to login.jsp with message
                    String errorMsg = URLEncoder.encode("Invalid username or password..!", "UTF-8");
                    response.sendRedirect("login.jsp?msg=" + errorMsg);
                }

            } catch (Exception e) {
                out.println("Error: " + e.getMessage());
            } finally {
                try {
                    if (rs != null) {
                        rs.close();
                    }
                } catch (SQLException e) {
                }
                try {
                    if (pstmt != null) {
                        pstmt.close();
                    }
                } catch (SQLException e) {
                }
                try {
                    if (conn != null) {
                        conn.close();
                    }
                } catch (SQLException e) {
                }
            }
        %>
    </body>
</html>
