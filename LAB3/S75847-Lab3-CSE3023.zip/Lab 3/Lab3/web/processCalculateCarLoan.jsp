<%-- 
    Document   : processCalculateCarLoan
    Created on : 14 Apr 2026, 12:24:27 pm
    Author     : Asus
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>process calculate car loan</title>
    </head>
    <body>
        <h2>Perform Car Loan Calculation</h2>

        <fieldset>
        <legend><b style="color:blue; font-size:1.2em;">Details of car loan:</b></legend>
        <%
            // 1. Retrieve data as Strings
            String myAmountStr = request.getParameter("my_Loan");
            String myPeriodStr = request.getParameter("my_period");

            // 2. Initialize calculation variables
            double loanRequest = 0;
            int period = 0;
            double totalLoan = 0;
            double interestRate = 0.045; // 4.5% based on your screenshot example

            // 3. Convert Strings to numbers and calculate
            if (myAmountStr != null && myPeriodStr != null) {
                loanRequest = Double.parseDouble(myAmountStr);
                period = Integer.parseInt(myPeriodStr);
                
                // Formula: Total = Principal + (Principal * Rate * Years)
                totalLoan = loanRequest + (loanRequest * interestRate * period);
            }
        %>

        <p>Loan Request : <%= loanRequest %></p>
        <p>Period of payment : <%= period %></p>
        <p>Total Loan (+ interest) : <%= totalLoan %></p>
    </fieldset>
    </body>
</html>
