<%-- 
    Document   : footerPage
    Created on : 14 Apr 2026, 2:24:25 pm
    Author     : Asus
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Footer Page</title>
    </head>
    <body>
        <footer style="background-color: #FDE5C6; text-align: center;">
            &copy;2026-Safirul
        </footer>
    </body>
</html>
