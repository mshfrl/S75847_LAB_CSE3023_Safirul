<%-- 
    Document   : headerPage
    Created on : 14 Apr 2026, 2:20:25 pm
    Author     : Asus
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Header Page</title>
    </head>
    <body>
        <h1 style="background-color: #FDE5C6; text-align: center;">ABC Sdn Bhd</h1>
    </body>
</html>
