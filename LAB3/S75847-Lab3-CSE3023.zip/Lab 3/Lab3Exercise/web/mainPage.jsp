<%-- 
    Document   : mainPage.jsp
    Created on : 14 Apr 2026, 2:39:44 pm
    Author     : Asus
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Main Page - Student Club Registration</title>
    </head>
    <body>


        <%@ include file="header.jsp" %>
        <h1>Welcome to student club registration system</h1>
        <h2>Please click the options in the navigation bar to proceed the next actions!</h2>


        <%@ include file="footer.jsp" %>

    </body>
</html>
