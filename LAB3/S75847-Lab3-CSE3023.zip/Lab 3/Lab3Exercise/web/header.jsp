<%-- 
    Document   : header
    Created on : 14 Apr 2026, 2:42:00 pm
    Author     : Asus
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Header Page</title>
    </head>
    <body>
        <h1 style="background-color: #FDE5C6; text-align: center;">Student Club Registration System</h1>

        <a href="registerClub.jsp">Register Club</a>
        <a href="feeCalculator.jsp">Fee Calculator</a>
        <a href="memberDirectory.jsp">Club Member Directory</a>


    </body>
</html>