<%-- 
    Document   : registerClub
    Created on : 14 Apr 2026, 2:45:17 pm
    Author     : Asus
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Registration Form</title>
    </head>
    <body>
        <%@ include file="header.jsp" %>
        <h1>Please Register Below</h1>
        <form id="memberform" action="processRegistration.jsp" method="post"
              onsubmit="return checkICNo()">
            <fieldset>
                <legend>Member Registration</legend>
                <label for="Name">Name</label>
                <input type="text" id="name" name="myName" size="15"
                       placeholder="E.g. Safirul"><br/>
                <label for="MatricNumer">Matric Number</label>
                <input type="text" id="matricNo" name="myMatric" size="45"
                       placeholder="Key-in your Matric Number"><br/>

                <label for="Club">Selected Club</label>
                <input type="text" id="club" name="myClub" size="45"
                       placeholder="put your selected club"><br/>

                <p>
                    <input type="submit" id="btnSubmit" value="Submit">
                    <input type="reset" id="btnCancel" value="Cancel">
                </p>
            </fieldset>
        </form>
        <%@ include file="footer.jsp" %>

    </body>
</html>
