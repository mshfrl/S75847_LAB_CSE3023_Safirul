<%-- 
    Document   : forwardInfo
    Created on : 21 Apr 2026, 2:00:00 pm
    Author     : Asus
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>forward jsp</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <h1>forward jsp</h1>

        <%
            String name = request.getParameter("uname");
            String email = request.getParameter("email");
            String nationality = request.getParameter("nationality");
            String background = request.getParameter("background");
        %>

        <p>Name: <%= name%></p>
        <p>Email: <%= email%></p>
        <p>Nationality: <%= nationality%></p>
        <p>Background: <%= background%></p>


    </body>
</html>
