<%-- 
    Document   : processInsuranceQuo
    Created on : 21 Apr 2026, 2:06:24 pm
    Author     : Asus
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>process quo</title>
        <link rel='stylesheet' href='style.css'>
    </head>
    <body>
        <h1>process quo</h1>

        <%
// Retrieve form data
            String icno = request.getParameter("icno");
            String name = request.getParameter("name");
            String coverage = request.getParameter("coverage");
            String ncdStr = request.getParameter("ncd");
            double price = 0;
            double ncd = 0;
            try {
                price = Double.parseDouble(request.getParameter("price"));
                ncd = Double.parseDouble(ncdStr);
            } catch (Exception e) {
                price = 0;
                ncd = 0;
            }
// Business Logic
            double rate = 0;
            String coverageDisplay = "";
            if ("comprehensive".equals(coverage)) {
                rate = 0.05; // 5%
                coverageDisplay = "Comprehensive";
            } else {
                rate = 0.03; // 3%
                coverageDisplay = "Third Party";
            }
// Base insurance calculation

            double insurance = price * rate;
// Apply NCD discount
            double discount = insurance * ncd;
            double afterNCD = insurance - discount;
// Add 8% SST
            double sst = afterNCD * 0.08;
            double finalAmount = afterNCD + sst;
        %>

    </body>
</html>
