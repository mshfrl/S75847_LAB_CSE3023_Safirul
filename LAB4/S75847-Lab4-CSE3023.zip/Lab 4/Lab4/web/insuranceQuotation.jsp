<%-- 
    Document   : insuranceQuotation
    Created on : 21 Apr 2026, 2:04:43 pm
    Author     : Asus
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>insurance</title>
        <link rel="stylesheet" href='style.css'>
    </head>
    <body>
        <div class="container">
            <h1>Insurance Quotation</h1>

            <div class="card">
                <form action="processQuotation.jsp" method="POST">

                    <fieldset>
                        <legend>Insurance Calculation</legend>

                        <div class="form-group">
                            <label for="icNo">IC No*</label>
                            <input type="text" id="icNo" name="icNo" placeholder="E.g. 821210-05-3478" required>
                        </div>

                        <div class="form-group">
                            <label for="name">Name*</label>
                            <input type="text" id="name" name="name" placeholder="Enter name" required>
                        </div>

                        <div class="form-group">
                            <label for="marketPrice">Market Price*</label>
                            <input type="number" id="marketPrice" name="marketPrice" placeholder="Price" step="any" required>
                        </div>

                        <div class="form-group">
                            <label for="coverageType">Coverage Type</label>
                            <select id="coverageType" name="coverageType" required>
                                <option value="Third Party">Third Party</option>
                                <option value="Comprehensive">Comprehensive</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="ncd">No Claims Discount (NCD)</label>
                            <select id="ncd" name="ncd" required>
                                <option value="10">10%</option>
                                <option value="25">25%</option>
                                <option value="38.33">38.33%</option>
                                <option value="45">45%</option>
                                <option value="55">55%</option>
                            </select>
                        </div>

                        <div class="button-group">
                            <button type="submit" class="btn btn-submit">Submit</button>
                            <button type="reset" class="btn btn-cancel">Cancel</button>
                        </div>

                    </fieldset>
                </form>
            </div>
        </div>        
    </body>
</html>
