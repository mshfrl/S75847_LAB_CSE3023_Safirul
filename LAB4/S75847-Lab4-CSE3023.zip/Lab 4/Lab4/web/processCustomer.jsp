<%-- 
    Document   : processCustomer
    Created on : 21 Apr 2026, 11:55:54 am
    Author     : Asus
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <%
            // Fixed price
            final double price = 10.0;
            
            // Retrieve form data
            String cust_no = request.getParameter("customerCode");
            String cust_type = request.getParameter("customerType");
            int quantity = 0;
            
            try {
                quantity = Integer.parseInt(request.getParameter("quantity"));
            } catch (Exception e) {
                quantity = 0;
            }

             // Business logic
            double total = 0;
            String message = "";
            
            // Added null check for cust_type to prevent NullPointerException
            if (cust_type != null) {
                if (cust_type.equals("1") && quantity > 100) {
                    message = "You're entitled to 10% discount";
                    total = quantity * price * 0.9;
                } else if (cust_type.equals("2") && quantity > 100) {
                    message = "You're entitled to 25% discount";
                    total = quantity * price * 0.75;
                } else {
                    message = "You're not entitled to any discount";
                    total = quantity * price;
                }
            } else {
                message = "Customer type not selected.";
                cust_type = "1"; // Default fallback
            }
            
            // Display customer type
            String custTypeDisplay = cust_type.equals("1")
                    ? "Normal Customer" : "Privilege Customer";
        %>

        <div class="container">
            <h1>Use JSP Scriptlet and JSP Expression in Application</h1>
            
            <div class="card">
                <h2 class="form-title">Customer Discount Result</h2>

                <div class="result-grid">
                    <div class="result-box">
                        <h3>Customer Details</h3>
                        <div class="result-group">
                            <label>Customer Code:</label>
                            <p><%= cust_no != null ? cust_no : "None provided" %></p>
                        </div>
                        <div class="result-group">
                            <label>Customer Type:</label>
                            <p><%= custTypeDisplay %></p>
                        </div>
                    </div>

                    <div class="result-box">
                        <h3>Order Summary</h3>
                        <div class="result-group">
                            <label>Quantity:</label>
                            <p><%= quantity %></p>
                        </div>
                        <div class="result-group">
                            <label>Discount Status:</label>
                            <p><%= message %></p>
                        </div>
                        <div class="result-group">
                            <label>Total Amount:</label>
                            <p>RM <%= String.format("%.2f", total) %></p> 
                        </div>
                    </div>
                </div>

                <div class="button-group">
                    <button onclick="history.back()" class="btn btn-back">Go Back</button>
                </div>
            </div>
        </div>
    </body>
</html>
