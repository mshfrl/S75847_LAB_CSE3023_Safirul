<%-- 
    Document   : resultBMI
    Created on : 21 Apr 2026, 2:46:37 pm
    Author     : Asus
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Result BMI</title>
    </head>
    <body>
        <%@ include file="head.jsp" %>

        <h3>BMI Result</h3>

        <%
            String finalBmi = request.getParameter("bmiValue");
            String finalCategory = request.getParameter("bmiCategory");

            if (finalBmi == null || finalCategory == null) {
                finalBmi = "0.00";
                finalCategory = "No data yet. Please calculate first.";
            }
        %>

        <ul>
            <li><strong>Calculated BMI:</strong> <%= finalBmi%></li>
            <li><strong>Health Category:</strong> <%= finalCategory%></li>
        </ul>

        <br>
        <a href="bmiCalculator.jsp"><button>Calculate Again</button></a>

        <%@ include file="foot.jsp" %>
    </body>
</html>
