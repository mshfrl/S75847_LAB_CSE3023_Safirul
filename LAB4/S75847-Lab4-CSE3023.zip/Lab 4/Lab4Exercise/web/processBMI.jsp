<%-- 
    Document   : processBMI
    Created on : 21 Apr 2026, 2:45:36 pm
    Author     : Asus
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Process BMI</title>
    </head>
    <body>
        <%
            String w = request.getParameter("weight");
            String h = request.getParameter("height");

            double weight = 0;
            double height = 0;
            double bmi = 0;
            String category = "";

            try {
                weight = Double.parseDouble(w);
                height = Double.parseDouble(h);
                
                if (height > 0) {
                    bmi = weight / (height * height);

                    if (bmi < 18.5) {
                        category = "Underweight";
                    } else if (bmi <= 25) {
                        category = "Normal";
                    } else {
                        category = "Overweight";
                    }
                } else {
                    category = "Error: Height cannot be zero";
                }
            } catch (Exception e) {
                category = "Error: Please enter valid numbers";
            }

            String formattedBmi = String.format("%.2f", bmi);
        %>

        <jsp:forward page="resultBMI.jsp">
            <jsp:param name="bmiValue" value="<%= formattedBmi%>" />
            <jsp:param name="bmiCategory" value="<%= category%>" />
        </jsp:forward>
    </body>
</html>
