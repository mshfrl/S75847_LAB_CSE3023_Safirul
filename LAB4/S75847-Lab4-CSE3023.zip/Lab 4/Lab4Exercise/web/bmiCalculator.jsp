<%-- 
    Document   : bmiCalculator
    Created on : 21 Apr 2026, 2:31:50 pm
    Author     : Asus
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>BMI calculator</title>
        <link rel='stylesheet' href="style.css">
    </head>
    <body>
        <%@ include file="head.jsp" %>

        <h3>BMI Calculator</h3>

        <form action="processBMI.jsp" method="POST">
            <p>
                <label>Weight (kg):</label>
                <input type="number" name="weight" step="any" required>
            </p>
            <p>
                <label>Height (m):</label>
                <input type="number" name="height" step="any" required>
            </p>
            <input type="submit" value="Calculate BMI">
        </form>

        <%@ include file="foot.jsp" %>

    </body>
</html>
