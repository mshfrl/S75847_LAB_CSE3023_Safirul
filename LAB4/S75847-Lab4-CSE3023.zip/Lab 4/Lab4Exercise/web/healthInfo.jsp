<%-- 
    Document   : healthInfo
    Created on : 21 Apr 2026, 2:47:42 pm
    Author     : Asus
--%>
<%@ page import="java.util.ArrayList" %>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Health Info</title>
    </head>
    <body>
        

        <%@ include file="head.jsp" %>

        <h3>Health Info Reference</h3>

        <%
            ArrayList<String> bmiList = new ArrayList<>();
            bmiList.add("BMI < 18.5 : Underweight");
            bmiList.add("18.5 to 25 : Normal");
            bmiList.add("BMI > 25 : Overweight");
        %>

        <table border="1" cellpadding="10" cellspacing="0">
            <tr>
                <th style="background-color: #f2f2f2;">BMI Categories</th>
            </tr>
            <%
                // Loop through the ArrayList
                for (String info : bmiList) {
            %>
            <tr>
                <td><%= info%></td>
            </tr>
            <%
                }
            %>
        </table>

        <%@ include file="foot.jsp" %>
    </body>
</html>
