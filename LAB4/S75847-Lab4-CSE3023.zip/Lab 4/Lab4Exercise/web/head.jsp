<%-- 
    Document   : head
    Created on : 21 Apr 2026, 2:30:20 pm
    Author     : Asus
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <header>
        <h2>UMT BMI</h2>
        <nav>
            <a href="bmiCalculator.jsp">BMI Calculator</a> | 
            | 
            <a href="healthInfo.jsp">Health Information</a>
        </nav>
        <hr>
    </header>
    </body>
</html>
