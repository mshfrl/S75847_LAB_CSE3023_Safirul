<%-- 
    Document   : foot
    Created on : 21 Apr 2026, 2:30:36 pm
    Author     : Asus
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <footer>
        <hr>
        <p>&copy; 2026 Faculty of Computer Science and Mathematics, UMT</p>
    </footer>
    </body>
</html>
